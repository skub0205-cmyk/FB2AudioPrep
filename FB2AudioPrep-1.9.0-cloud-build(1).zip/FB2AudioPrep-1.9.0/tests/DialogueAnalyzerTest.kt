package ru.fbaudioprep

private fun checkCase(condition: Boolean, message: String) {
    if (!condition) error("FAIL: $message")
    println("PASS: $message")
}

fun main() {
    val characters = listOf(
        CharacterProfile("Нико", listOf("Ник"), "мужской"),
        CharacterProfile("ИмИн", listOf("Имин"), "женский"),
        CharacterProfile("Ночи", emptyList(), "женский"),
        CharacterProfile("Нурина", emptyList(), "женский"),
        CharacterProfile("Самуру", emptyList(), "женский")
    )
    val analyzer = DialogueAnalyzer(characters)

    val first = analyzer.analyzeParagraph(
        "— Нико! Нико, мать твою! раздался снаружи раздражённый женский голос с лёгкими рычащими нотками."
    )
    checkCase(first.speaker == null, "обращение Нико не назначается говорящим")
    checkCase(first.addressedTo == "Нико", "адресат Нико распознаётся отдельно")
    checkCase(first.voice == "женский", "авторская подсказка женского голоса распознаётся")

    val book = """— Нико! Нико, мать твою! раздался снаружи раздражённый женский голос с лёгкими рычащими нотками.

— Да тут я, ту... АЙ! Да чтоб тебе ёжики спинами теребонькали...

«Нико, добро пожаловать!» — раздался в голове приветливый женский голос.

«На две минуты и тридцать семь секунд», — тут же выдал отчёт ИмИн."""
    val findings = analyzer.analyzeBook(book)
    checkCase(findings.size == 4, "все четыре диалоговых фрагмента найдены")
    checkCase(findings[0].speaker == null && findings[0].voice == "женский", "первая реплика остаётся женским голосом без выдуманного имени")
    checkCase(findings[1].speaker == "Нико", "следующая реплика связывается с адресатом Нико")
    checkCase(findings[2].speaker == "ИмИн" && findings[2].addressedTo == "Нико", "голос в приветствии связывается с ИмИн по следующему авторскому указанию, а Нико остаётся адресатом")
    checkCase(findings[2].voice == "женский" && findings[2].confidence < 0.7f, "сопоставление женского голоса с ИмИн помечается как предположение для ручной проверки")
    checkCase(findings[3].speaker == "ИмИн", "ИмИн определяется после конструкции «выдал отчёт ИмИн»")

    val direct = analyzer.analyzeParagraph("— Я всё понял, — сказала Ночи.")
    checkCase(direct.speaker == "Ночи", "имя после глагола речи определяется")
    val voiceOwner = analyzer.analyzeParagraph("— Нико! — вновь вырвал меня из раздумий голос Нурины.")
    checkCase(voiceOwner.speaker == "Нурина", "владелец голоса определяется по авторской конструкции «голос Нурины»")

    val before = analyzer.analyzeParagraph("ИмИн тихо ответила и закрыла канал.")
    checkCase(before.speaker == "ИмИн", "имя перед глаголом речи определяется")

    val falsePositive = analyzer.analyzeParagraph("— Нико, ты слышишь меня? — спросила Ночи.")
    checkCase(falsePositive.speaker == "Ночи", "говорящий не подменяется именем адресата в реплике")

    val interrupted = analyzer.analyzeBook("""— Нико! раздался женский голос.

Он оглянулся и посмотрел в сторону двери.

— Да тут я.""")
    checkCase(interrupted.last().speaker == null, "говорящий не переносится через абзац повествования")

    val delayedIdentity = analyzer.analyzeBook("""— Нико! Нико! — раздался снаружи женский голос.

— Да тут я.

«Нико, добро пожаловать!» — раздался в голове приветливый женский голос.

— Можно подумать, я так надолго отключался.

«На две минуты», — тут же выдал отчёт ИмИн.

— Нико! — вновь раздался голос Нурины.""")
    checkCase(delayedIdentity[0].speaker == "Нурина" && delayedIdentity[0].confidence < 0.7f,
        "внешний женский голос осторожно связывается с последующим упоминанием Нурины")
    checkCase(delayedIdentity[2].speaker == "ИмИн" && delayedIdentity[2].confidence < 0.7f,
        "голос в голове осторожно связывается с последующим указанием ИмИн")

    val proseOnly = DialogueAnalyzer(listOf(CharacterProfile("Ночи", emptyList(), "женский")))
    val proseBook = "Он сказал, что вернётся завтра.\n\n— Привет! — сказала Ночи.\n\nОна сказала, что это важно."
    val proseResults = proseOnly.analyzeBook(proseBook)
    checkCase(proseResults.size == 1, "обычное повествование с глаголами речи не попадает в список диалогов")
    checkCase(proseResults.single().speaker == "Ночи", "реплика с прямой речью по-прежнему распознаётся")
    val quotedWordBook = "Она посмотрела на «сверчок» и продолжила путь.\n\nОн сказал: «Пора идти»."
    val quotedWordResults = proseOnly.analyzeBook(quotedWordBook)
    checkCase(quotedWordResults.size == 1, "цитируемые слова в повествовании не считаются диалогом")
    val ambiguousAliasAnalyzer = DialogueAnalyzer(listOf(
        CharacterProfile("ИмИн", listOf("ИскИн"), "женский"),
        CharacterProfile("Ночи", listOf("ИскИн"), "женский")
    ))
    val ambiguousAlias = ambiguousAliasAnalyzer.analyzeParagraph("— Ответила ИскИн.")
    checkCase(ambiguousAlias.speaker == null, "общий псевдоним двух персонажей не назначается случайным образом")
    val parentheticalDash = "Он не прошёл — неэффективная трата ресурсов, как заявили ему."
    checkCase(proseOnly.analyzeBook(parentheticalDash).isEmpty(), "тире в авторском пояснении не считается репликой")
}
