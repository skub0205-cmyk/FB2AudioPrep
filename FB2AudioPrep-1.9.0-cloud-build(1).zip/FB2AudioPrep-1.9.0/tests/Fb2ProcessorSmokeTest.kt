import ru.fbaudioprep.AccentEngine
import ru.fbaudioprep.Fb2Processor
import java.io.ByteArrayInputStream
import javax.xml.parsers.DocumentBuilderFactory
import java.nio.charset.Charset

private val engine = AccentEngine(mapOf(
    "Молоко" to "Молоко́",
    "хорошо" to "хорошо́",
    "Нико" to "Ни́ко",
    "корова" to "коро́ва",
    "машина" to "маши́на",
    "ёлка" to "ё́лка",
    "ёжик" to "ёжи́к"
))

fun main() {
    val xml = """<?xml version="1.0" encoding="UTF-8"?>
<FictionBook xmlns="http://www.gribuser.ru/xml/fictionbook/2.0" xmlns:xlink="http://www.w3.org/1999/xlink">
  <description><title-info><book-title>Молоко в заголовке не трогаем</book-title></title-info></description>
  <body><section><title><p>Глава</p></title><p>Молоко и хорошо, Нико!</p><p>Уже есть молоко́.</p><image xlink:href="#cover"/></section></body>
  <body name="notes"><section><p>Молоко в примечании</p></section></body>
  <binary id="cover" content-type="image/png">aGVsbG8=</binary>
</FictionBook>""".toByteArray(Charsets.UTF_8)
    val result = Fb2Processor.accentuate(xml, engine)
    val out = result.xml.toString(Charsets.UTF_8)
    check("Молоко́ и хорошо́, Ни́ко!" in out)
    check("Молоко в заголовке не трогаем" in out)
    check("<binary id=\"cover\" content-type=\"image/png\">aGVsbG8=</binary>" in out)
    check("name=\"notes\"" in out && "Молоко́ в примечании" in out)
    check("Уже есть молоко́." in out)
    val parsed = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }
        .newDocumentBuilder().parse(ByteArrayInputStream(result.xml))
    check(parsed.documentElement.localName == "FictionBook")
    check(result.changedWords == 4) { "changed=${result.changedWords}" }
    check(result.alreadyAccentedWords >= 1)

    // External DTD and named entities are copied literally; no network lookup or entity loss.
    val withDtd = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE FictionBook PUBLIC "-//FictionBook//DTD FictionBook 2.0//EN" "http://www.gribuser.ru/xml/fictionbook/2.0/fictionbook.dtd">
<FictionBook><body><section><p>Молоко &amp; хорошо &mdash; Нико</p></section></body></FictionBook>""".toByteArray(Charsets.UTF_8)
    val dtdOut = Fb2Processor.accentuate(withDtd, engine).xml.toString(Charsets.UTF_8)
    check("<!DOCTYPE FictionBook PUBLIC" in dtdOut)
    check("&amp;" in dtdOut && "&mdash;" in dtdOut)
    check("Молоко́ &amp; хорошо́ &mdash; Ни́ко" in dtdOut) { dtdOut }

    // CDATA text is accented without removing its CDATA wrapper.
    val cdata = "<FictionBook><body><p><![CDATA[Молоко и хорошо]]></p></body></FictionBook>".toByteArray()
    val cdataOut = Fb2Processor.accentuate(cdata, engine).xml.toString(Charsets.UTF_8)
    check("<![CDATA[Молоко́ и хорошо́]]>" in cdataOut)

    // BOM and UTF-16 encoding survive round-trip.
    val utf8Bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) +
        "<FictionBook><body><p>Молоко</p></body></FictionBook>".toByteArray(Charsets.UTF_8)
    val bomOut = Fb2Processor.accentuate(utf8Bom, engine).xml
    check(bomOut.take(3) == listOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
    check(bomOut.toString(Charsets.UTF_8).contains("Молоко́"))

    val utf16Text = "<?xml version=\"1.0\" encoding=\"UTF-16LE\"?><FictionBook><body><p>Молоко</p></body></FictionBook>"
    val utf16Bytes = byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + utf16Text.toByteArray(Charset.forName("UTF-16LE"))
    val utf16Out = Fb2Processor.accentuate(utf16Bytes, engine).xml
    check(utf16Out.take(2) == listOf(0xFF.toByte(), 0xFE.toByte()))
    check(utf16Out.copyOfRange(2, utf16Out.size).toString(Charset.forName("UTF-16LE")).contains("Молоко́"))



    // A single word split across inline markup is analyzed as one lexical word.
    val splitInline = """<FictionBook><body><section><p>ко<emphasis>ро</emphasis>ва и ма<strong>ши</strong>на</p></section></body></FictionBook>""".toByteArray()
    val splitResult = Fb2Processor.accentuate(splitInline, engine)
    val splitOut = splitResult.xml.toString(Charsets.UTF_8)
    check("ко<emphasis>ро́</emphasis>ва" in splitOut) { splitOut }
    check("ма<strong>ши́</strong>на" in splitOut) { splitOut }
    check(splitResult.changedWords == 2) { "split changed=${splitResult.changedWords}" }
    DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ByteArrayInputStream(splitResult.xml))

    // Structural tags remain word boundaries: separate paragraphs are never joined.
    val blockBoundary = "<FictionBook><body><section><p>ко</p><p>рова</p></section></body></FictionBook>".toByteArray()
    val boundaryResult = Fb2Processor.accentuate(blockBoundary, engine)
    val boundaryOut = boundaryResult.xml.toString(Charsets.UTF_8)
    check("<p>ко</p><p>рова</p>" in boundaryOut) { boundaryOut }
    check(boundaryResult.changedWords == 0)

    // A numeric entity encoding a Cyrillic letter participates in the same split word.
    val entitySplit = "<FictionBook><body><p>ко&#1088;ова</p></body></FictionBook>".toByteArray()
    val entityOut = Fb2Processor.accentuate(entitySplit, engine).xml.toString(Charsets.UTF_8)
    check("ко&#1088;о́ва" in entityOut) { entityOut }

    // A numeric acute entity is recognized as an existing stress mark, not duplicated.
    val numericAcute = "<FictionBook><body><p>Молоко&#769;</p></body></FictionBook>".toByteArray()
    val numericResult = Fb2Processor.accentuate(numericAcute, engine)
    val numericOut = numericResult.xml.toString(Charsets.UTF_8)
    check(numericOut.contains("Молоко&#769;"))
    check(numericResult.changedWords == 0 && numericResult.alreadyAccentedWords == 1)

    // Legacy Windows-1251 cannot encode U+0301; export uses a numeric XML reference instead.
    val cp1251 = Charset.forName("windows-1251")
    val cp1251Text = "<?xml version=\"1.0\" encoding=\"windows-1251\"?><FictionBook><body><p>Молоко</p></body></FictionBook>"
    val cp1251Out = Fb2Processor.accentuate(cp1251Text.toByteArray(cp1251), engine).xml
    val cp1251Decoded = cp1251Out.toString(cp1251)
    check("encoding=\"windows-1251\"" in cp1251Decoded)
    check("Молоко&#769;" in cp1251Decoded)

    // CDATA in a legacy encoding is converted to escaped XML text when a numeric
    // character reference is needed; references inside CDATA would remain literal.
    val cp1251CdataText = "<?xml version=\"1.0\" encoding=\"windows-1251\"?><FictionBook><body><p><![CDATA[Молоко]]></p></body></FictionBook>"
    val cp1251CdataOut = Fb2Processor.accentuate(cp1251CdataText.toByteArray(cp1251), engine).xml
    val cp1251Doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ByteArrayInputStream(cp1251CdataOut))
    val cdataText = cp1251Doc.getElementsByTagName("p").item(0).textContent
    check(cdataText == "Молоко\u0301") { cdataText }
    check("<![CDATA[" !in cp1251CdataOut.toString(cp1251))

    // Decomposed Cyrillic letters: diaeresis is part of the preceding letter and
    // must remain before the newly inserted acute accent.
    val decomposed = "<FictionBook><body><p>е\u0308лка</p></body></FictionBook>".toByteArray(Charsets.UTF_8)
    val decomposedResult = Fb2Processor.accentuate(decomposed, engine)
    val decomposedOut = decomposedResult.xml.toString(Charsets.UTF_8)
    check("е\u0308\u0301лка" in decomposedOut) { decomposedOut }
    check(decomposedResult.changedWords == 1)
    DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ByteArrayInputStream(decomposedResult.xml))

    // A later stressed vowel must keep its letter index when the first letter is decomposed.
    val decomposedLaterStress = "<FictionBook><body><p>е\u0308жик</p></body></FictionBook>".toByteArray(Charsets.UTF_8)
    val laterStressOut = Fb2Processor.accentuate(decomposedLaterStress, engine).xml.toString(Charsets.UTF_8)
    check("е\u0308жи\u0301к" in laterStressOut) { laterStressOut }

    // The combining diaeresis may follow a closing inline tag; the stress mark is
    // placed after the complete grapheme, not between its base and diaeresis.
    val splitGrapheme = "<FictionBook><body><p><emphasis>е</emphasis>\u0308лка</p></body></FictionBook>".toByteArray(Charsets.UTF_8)
    val splitGraphemeOut = Fb2Processor.accentuate(splitGrapheme, engine).xml.toString(Charsets.UTF_8)
    check("<emphasis>е</emphasis>\u0308\u0301лка" in splitGraphemeOut) { splitGraphemeOut }

    println("PASS: basic FB2, multiple body sections, metadata untouched, binary preserved, DTD/entities, CDATA, UTF-8 BOM, UTF-16 BOM, numeric acute entity, Windows-1251, inline-tag-split words, numeric-letter entities, Windows-1251 CDATA, decomposed Cyrillic combining marks")
}
