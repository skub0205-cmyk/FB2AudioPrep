#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/fbaudioprep-jvm-tests.jar"

kotlinc \
  "$ROOT/app/src/main/java/ru/fbaudioprep/AccentEngine.kt" \
  "$ROOT/app/src/main/java/ru/fbaudioprep/Fb2Processor.kt" \
  "$ROOT/app/src/main/java/ru/fbaudioprep/Fb2InlineWordProcessor.kt" \
  "$ROOT/app/src/main/java/ru/fbaudioprep/BookImportSupport.kt" \
  "$ROOT/app/src/main/java/ru/fbaudioprep/DialogueAnalyzer.kt" \
  "$ROOT/app/src/main/java/ru/fbaudioprep/TeraTtsManualPackExporter.kt" \
  "$ROOT/tests/BookImportSupportTest.kt" \
  "$ROOT/tests/Fb2ProcessorSmokeTest.kt" \
  "$ROOT/tests/DialogueAnalyzerTest.kt" \
  "$ROOT/tests/TeraTtsManualPackExporterTest.kt" \
  -include-runtime -d "$OUT"

java -cp "$OUT" BookImportSupportTestKt
java -cp "$OUT" Fb2ProcessorSmokeTestKt
java -cp "$OUT" ru.fbaudioprep.DialogueAnalyzerTestKt
java -cp "$OUT" ru.fbaudioprep.TeraTtsManualPackExporterTestKt

echo "ALL JVM CHECKS PASSED"
