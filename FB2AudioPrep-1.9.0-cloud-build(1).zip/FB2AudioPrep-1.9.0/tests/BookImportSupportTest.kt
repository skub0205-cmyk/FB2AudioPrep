import ru.fbaudioprep.BookImportSupport
import java.nio.charset.Charset

fun main() {
    val utf8 = "Привет, книга!".toByteArray(Charsets.UTF_8)
    val utf8Decoded = BookImportSupport.decodeText(utf8)
    check(utf8Decoded.text == "Привет, книга!")
    check(utf8Decoded.charsetName.equals("UTF-8", true))
    check(!utf8Decoded.hadBom)

    val utf8Bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + utf8
    val utf8BomDecoded = BookImportSupport.decodeText(utf8Bom)
    check(utf8BomDecoded.text == "Привет, книга!")
    check(utf8BomDecoded.hadBom)

    val cp1251 = "Привет, книга!".toByteArray(Charset.forName("windows-1251"))
    val cp1251Decoded = BookImportSupport.decodeText(cp1251)
    check(cp1251Decoded.text == "Привет, книга!") { cp1251Decoded.text }
    check(cp1251Decoded.charsetName.equals("windows-1251", true))

    val utf16LeText = "Глава 1".toByteArray(Charset.forName("UTF-16LE"))
    val utf16Le = byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + utf16LeText
    check(BookImportSupport.decodeText(utf16Le).text == "Глава 1")

    val utf16BeText = "Глава 2".toByteArray(Charset.forName("UTF-16BE"))
    val utf16Be = byteArrayOf(0xFE.toByte(), 0xFF.toByte()) + utf16BeText
    check(BookImportSupport.decodeText(utf16Be).text == "Глава 2")

    // BOM-less UTF-16 XML/text signatures.
    val utf16NoBomLe = "<FictionBook>текст</FictionBook>".toByteArray(Charset.forName("UTF-16LE"))
    check(BookImportSupport.decodeText(utf16NoBomLe).text == "<FictionBook>текст</FictionBook>")
    val utf16NoBomBe = "<FictionBook>текст</FictionBook>".toByteArray(Charset.forName("UTF-16BE"))
    check(BookImportSupport.decodeText(utf16NoBomBe).text == "<FictionBook>текст</FictionBook>")

    // Archive selection: FB2 beats TXT; within an extension, root-level and then lexical path wins.
    check(BookImportSupport.compareArchiveNames("book.txt", "folder/book.fb2") > 0)
    check(BookImportSupport.compareArchiveNames("book.fb2", "folder/book.fb2") < 0)
    check(BookImportSupport.compareArchiveNames("a/book.fb2", "b/book.fb2") < 0)
    check(BookImportSupport.compareArchiveNames("folder/book.txt", "book.txt") > 0)

    println("PASS: UTF-8, UTF-8 BOM, Windows-1251 fallback, UTF-16LE/BE BOM, BOM-less UTF-16 signatures, deterministic ZIP ranking")
}
