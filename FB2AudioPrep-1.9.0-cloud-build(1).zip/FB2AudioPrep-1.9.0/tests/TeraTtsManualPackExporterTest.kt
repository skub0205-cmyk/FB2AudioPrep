package ru.fbaudioprep

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

fun main() {
    val characters = listOf(
        CharacterProfile("ИмИн", listOf("ИскИн", "ИмИн-корабль"), "женский"),
        CharacterProfile("Нико", listOf("Ник"), "мужской"),
        CharacterProfile("Неизвестный", emptyList(), "не задан")
    )
    val findings = listOf(
        DialogueFinding(
            fragment = "— Нико! Нико, мать твою! — раздался раздражённый женский голос.",
            speaker = null,
            voice = "женский",
            confidence = 0.72f,
            reason = "Пол голоса указан автором, но говорящий персонаж не назван",
            addressedTo = "Нико"
        ),
        DialogueFinding(
            fragment = "«Нико, добро пожаловать!» — раздался в голове приветливый женский голос.",
            speaker = "ИмИн",
            voice = "женский",
            confidence = 0.96f,
            reason = "Имя персонажа связано с глаголом речи вне прямой реплики",
            addressedTo = "Нико"
        ),
        DialogueFinding(
            fragment = "— Да тут я! — ответил Нико.",
            speaker = "Нико",
            voice = "мужской",
            confidence = 1f,
            reason = "Говорящий назначен пользователем"
        ),
        DialogueFinding(
            fragment = "«Нико, добро пожаловать!» — раздался женский голос.",
            speaker = "ИмИн",
            voice = "женский",
            confidence = 0.62f,
            reason = "Предположительный владелец голоса по последующему авторскому указанию; обязательно проверьте вручную",
            addressedTo = "Нико"
        )
    )

    val bytes = TeraTtsManualPackExporter.encode("Книга: тест.fb2", characters, findings)
    val entries = linkedMapOf<String, String>()
    ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
        while (true) {
            val entry = zip.nextEntry ?: break
            entries[entry.name] = zip.readBytes().toString(Charsets.UTF_8)
        }
    }

    check(entries.keys == setOf("00-ИНСТРУКЦИЯ.txt", "01-ПЕРСОНАЖИ.csv", "02-ДИАЛОГИ.csv"))
    check(entries.getValue("00-ИНСТРУКЦИЯ.txt").contains("НЕ файл импорта TeraTTS"))
    check(entries.getValue("01-ПЕРСОНАЖИ.csv").startsWith("\uFEFF"))
    check(entries.getValue("01-ПЕРСОНАЖИ.csv").contains("ИмИн"))
    check(entries.getValue("01-ПЕРСОНАЖИ.csv").contains("ИскИн, ИмИн-корабль"))
    check(entries.getValue("01-ПЕРСОНАЖИ.csv").contains("женский"))
    check(entries.getValue("02-ДИАЛОГИ.csv").contains("Нико"))
    check(entries.getValue("02-ДИАЛОГИ.csv").contains("да"))
    check(entries.getValue("02-ДИАЛОГИ.csv").contains("подтверждено вручную"))
    check(entries.getValue("02-ДИАЛОГИ.csv").contains("предположение — проверить"))
    check(entries.getValue("02-ДИАЛОГИ.csv").contains("раздался раздражённый женский голос"))
    println("PASS: manual pack contains instruction, character aliases and voice genders, dialogue attribution, manual-correction marker, and explicit non-import disclaimer")
}
