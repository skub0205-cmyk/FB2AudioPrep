package ru.fbaudioprep

data class CharacterProfile(
    val name: String,
    val aliases: List<String>,
    val voice: String
)

data class DialogueFinding(
    val fragment: String,
    val speaker: String?,
    val voice: String?,
    val confidence: Float,
    val reason: String,
    /** Character being addressed in the spoken words; this is not the speaker. */
    val addressedTo: String? = null
)

/**
 * Conservative paragraph-level dialogue attribution.
 * Names inside a spoken phrase are treated as possible forms of address,
 * never as proof that the named character is speaking.
 */
class DialogueAnalyzer(private val characters: List<CharacterProfile>) {
    private val speechVerbs = listOf(
        "сказал", "сказала", "сказали", "сказать", "ответил", "ответила", "ответили",
        "произнёс", "произнес", "произнесла", "произнесли", "проговорил", "проговорила",
        "крикнул", "крикнула", "крикнули", "спросил", "спросила", "спросили",
        "буркнул", "буркнула", "прошептал", "прошептала", "отозвался", "отозвалась",
        "добавил", "добавила", "выдал", "выдала", "произнёс", "произнесла",
        "прошипел", "прошипела", "прорычал", "прорычала", "проворчал", "проворчала",
        "заявил", "заявила", "заявили", "объявил", "объявила", "объявили",
        "сообщил", "сообщила", "сообщили", "пояснил", "пояснила", "пояснили",
        "подтвердил", "подтвердила", "подтвердили", "поинтересовался", "поинтересовалась",
        "воскликнул", "воскликнула", "попросил", "попросила", "попросили"
    ).distinct()

    private val passiveVoiceVerbs = listOf(
        "раздался", "раздалась", "раздались", "послышался", "послышалась", "послышались",
        "прозвучал", "прозвучала", "прозвучали", "донёсся", "донесся", "донеслась", "донеслись"
    )

    private data class Alias(val value: String, val profile: CharacterProfile)

    private val aliases = characters.flatMap { character ->
        (character.aliases + character.name)
            .filter { it.isNotBlank() }
            .distinctBy { normalize(it) }
            .map { Alias(it.trim(), character) }
    }.groupBy { normalize(it.value) }
        // A shared alias such as the generic word "ИскИн" must not be assigned
        // arbitrarily to one of two different characters.
        .filterValues { matches -> matches.map { normalize(it.profile.name) }.distinct().size == 1 }
        .values.flatten()
        .sortedByDescending { it.value.length }

    private val speechVerbPattern = speechVerbs.joinToString("|") { Regex.escape(it) }
    private val passiveVerbPattern = passiveVoiceVerbs.joinToString("|") { Regex.escape(it) }

    private fun normalize(value: String): String = value
        .lowercase()
        .replace('ё', 'е')
        .filter { it.isLetterOrDigit() }

    private fun aliasRegex(alias: String): Regex = Regex(
        "(?iu)(?<![\\p{L}\\p{N}_])${Regex.escape(alias)}(?![\\p{L}\\p{N}_])"
    )

    private fun findAlias(text: String): CharacterProfile? {
        for (alias in aliases) {
            if (aliasRegex(alias.value).containsMatchIn(text)) return alias.profile
        }
        return null
    }

    private fun findAliasName(text: String): String? {
        for (alias in aliases) {
            if (aliasRegex(alias.value).containsMatchIn(text)) return alias.profile.name
        }
        return null
    }

    private fun hasSpeechVerb(text: String): Boolean = Regex(
        "(?iu)(?<![\\p{L}\\p{M}])(?:$speechVerbPattern)(?![\\p{L}\\p{M}])"
    ).containsMatchIn(text)

    /** Remove quoted dialogue so a vocative cannot be mistaken for an attribution subject. */
    private fun attributionText(text: String): String {
        var result = text
        val quotePatterns = listOf("«[^»]*»", "“[^”]*”", "\"[^\"]*\"")
        quotePatterns.forEach { pattern -> result = Regex(pattern).replace(result, " ") }

        // In dash dialogue, keep the text outside the spoken span when both dashes exist.
        val firstDash = result.indexOf('—')
        if (firstDash >= 0) {
            val secondDash = result.indexOf('—', firstDash + 1)
            if (secondDash >= 0) {
                result = result.substring(0, firstDash) + " " + result.substring(secondDash + 1)
            } else if (firstDash == result.indexOfFirst { !it.isWhitespace() }) {
                // One-dash paragraph with trailing author narration: discard the spoken
                // part at a passive attribution verb, e.g. "— Нико! раздался голос".
                val tail = result.substring(firstDash + 1)
                val passive = Regex("(?iu)(?<![\\p{L}\\p{M}])(?:$passiveVerbPattern)(?![\\p{L}\\p{M}])")
                    .find(tail)
                result = if (passive != null) tail.substring(passive.range.first) else ""
            }
        }
        return result
    }

    private fun inflectedAliasForms(alias: String): List<String> {
        val value = alias.trim()
        val lower = value.lowercase()
        val forms = linkedSetOf(value)
        when {
            lower.endsWith("ия") -> {
                val stem = value.dropLast(2)
                listOf("ия", "ии", "ию", "ией").forEach { forms.add(stem + it) }
            }
            lower.endsWith("а") -> {
                val stem = value.dropLast(1)
                listOf("а", "ы", "е", "у", "ой", "ою").forEach { forms.add(stem + it) }
            }
            lower.endsWith("я") -> {
                val stem = value.dropLast(1)
                listOf("я", "и", "е", "ю", "ей", "ею").forEach { forms.add(stem + it) }
            }
            lower.endsWith("й") -> {
                val stem = value.dropLast(1)
                listOf("й", "я", "ю", "ем", "е").forEach { forms.add(stem + it) }
            }
        }
        return forms.toList().sortedByDescending { it.length }
    }

    /** Resolve explicit author phrases such as "голос Нурины". */
    private fun findVoiceOwner(text: String): CharacterProfile? {
        val outsideSpeech = attributionText(text)
        if (outsideSpeech.isBlank()) return null
        for (alias in aliases) {
            val forms = inflectedAliasForms(alias.value).joinToString("|") { Regex.escape(it) }
            val pattern = Regex(
                "(?iu)(?<![\\p{L}\\p{M}])(?:голос|голосок|голоса|голосом)\\s+(?:этой\\s+|этого\\s+)?(?:$forms)(?![\\p{L}\\p{M}])"
            )
            if (pattern.containsMatchIn(outsideSpeech)) return alias.profile
        }
        return null
    }

    private fun findExplicitSpeaker(text: String): CharacterProfile? {
        val outsideSpeech = attributionText(text)
        if (outsideSpeech.isBlank()) return null

        for (alias in aliases) {
            val name = Regex.escape(alias.value)
            val beforeVerb = Regex(
                "(?iu)(?<![\\p{L}\\p{N}_])$name(?![\\p{L}\\p{N}_])" +
                    "(?:\\s+[\\p{L}\\p{M}-]+){0,3}\\s+(?:$speechVerbPattern)(?![\\p{L}\\p{M}])"
            )
            val afterVerb = Regex(
                "(?iu)(?<![\\p{L}\\p{M}])(?:$speechVerbPattern)(?![\\p{L}\\p{M}])" +
                    "(?:\\s+[\\p{L}\\p{M}-]+){0,4}\\s+$name(?![\\p{L}\\p{N}_])"
            )
            if (beforeVerb.containsMatchIn(outsideSpeech) || afterVerb.containsMatchIn(outsideSpeech)) {
                return alias.profile
            }
        }
        return null
    }

    private fun extractSpeech(text: String): String {
        val quoted = Regex("«([^»]*)»|“([^”]*)”|\"([^\"]*)\"")
            .findAll(text)
            .mapNotNull { match -> match.groupValues.drop(1).firstOrNull { it.isNotEmpty() } }
            .joinToString(" ")
        if (quoted.isNotBlank()) return quoted

        val firstDash = text.indexOf('—')
        if (firstDash >= 0) {
            var end = text.indexOf('—', firstDash + 1)
            if (end < 0) {
                val tail = text.substring(firstDash + 1)
                val passive = Regex("(?iu)(?<![\\p{L}\\p{M}])(?:$passiveVerbPattern)(?![\\p{L}\\p{M}])")
                    .find(tail)
                end = if (passive == null) text.length else firstDash + 1 + passive.range.first
            }
            return text.substring(firstDash + 1, end.coerceAtLeast(firstDash + 1))
        }
        return text
    }

    private fun voiceHint(text: String): String? {
        val feminine = Regex("(?iu)женск[\\p{L}\\p{M}]*\\s+голос[\\p{L}\\p{M}]*")
        val masculine = Regex("(?iu)мужск[\\p{L}\\p{M}]*\\s+голос[\\p{L}\\p{M}]*")
        return when {
            feminine.containsMatchIn(text) -> "женский"
            masculine.containsMatchIn(text) -> "мужской"
            else -> null
        }
    }

    private fun voiceLocation(text: String): String? = when {
        Regex("(?iu)(в голове|в сознании|внутри головы|мысленный голос)").containsMatchIn(text) -> "head"
        Regex("(?iu)(снаружи|на общей волне|по внутренней связи|через динамик|из динамиков|в динамике)").containsMatchIn(text) -> "external"
        else -> null
    }

    private fun inferredVoiceLocation(findings: List<DialogueFinding>, index: Int): String? {
        voiceLocation(findings[index].fragment)?.let { return it }
        // A short preceding window carries the location through a reply from
        // the listener (e.g. a voice in the head, then the narrator answers).
        for (previous in index - 1 downTo (index - 2).coerceAtLeast(0)) {
            voiceLocation(findings[previous].fragment)?.let { return it }
        }
        return null
    }

    private fun sameVoiceGender(profile: CharacterProfile, voice: String): Boolean {
        val expected = when (profile.voice.lowercase()) {
            "женский", "f", "female" -> "женский"
            "мужской", "m", "male" -> "мужской"
            else -> null
        }
        return expected != null && expected == voice
    }

    private fun isDialogueLine(text: String): Boolean {
        val trimmed = text.trimStart()
        return trimmed.startsWith("—") || trimmed.startsWith("–") ||
            trimmed.startsWith("«") || trimmed.startsWith("“") || trimmed.startsWith("\"")
    }

    fun analyzeParagraph(paragraph: String): DialogueFinding {
        val p = paragraph.trim()
        if (p.isEmpty()) return DialogueFinding(p, null, null, 0f, "Пустой абзац")

        val addressedTo = findAliasName(extractSpeech(p))
        val voiceOwner = findVoiceOwner(p)
        if (voiceOwner != null) {
            val ownerVoice = voiceOwner.voice.takeUnless {
                it.isBlank() || it.equals("не задан", ignoreCase = true)
            } ?: voiceHint(p)
            return DialogueFinding(
                p, voiceOwner.name, ownerVoice, 0.94f,
                "Авторская конструкция «голос + имя» вне прямой реплики", addressedTo
            )
        }
        val explicitSpeaker = findExplicitSpeaker(p)
        if (explicitSpeaker != null) {
            return DialogueFinding(
                p, explicitSpeaker.name, explicitSpeaker.voice, 0.96f,
                "Имя персонажа связано с глаголом речи вне прямой реплики", addressedTo
            )
        }

        val gender = voiceHint(p)
        if (gender != null) {
            return DialogueFinding(
                p, null, gender, 0.72f,
                "Пол голоса указан автором, но говорящий персонаж не назван", addressedTo
            )
        }

        if (Regex(
                "(?iu)(?<![\\p{L}\\p{M}])(?:$passiveVerbPattern)(?![\\p{L}\\p{M}]).{0,140}(?<![\\p{L}\\p{M}])голос"
            ).containsMatchIn(p)
        ) {
            return DialogueFinding(
                p, null, null, 0.30f,
                "Упомянут голос, но его владелец не установлен", addressedTo
            )
        }

        return DialogueFinding(
            p, null, null, 0.10f,
            if (addressedTo != null) "Найдено обращение к персонажу; говорящий не установлен"
            else "Недостаточно данных. Имя внутри реплики не считается говорящим",
            addressedTo
        )
    }

    fun analyzeBook(text: String): List<DialogueFinding> {
        val sourceParagraphs = text.split(Regex("\\r?\\n\\s*\\r?\\n"))
            .map { it.trim() }
        val quotedSpeechPattern = Regex("«[^»]+»|“[^”]+”|\"[^\"]+\"")
        val dashDialoguePattern = Regex("(?m)(?:^|[:：])[\\s]*[—–]\\s+[^—–\\s]")
        val candidates = sourceParagraphs.mapIndexedNotNull { sourceIndex, paragraph ->
            val hasQuotedSpeech = quotedSpeechPattern.containsMatchIn(paragraph)
            val hasDashDialogue = dashDialoguePattern.containsMatchIn(paragraph)
            // A speech verb in ordinary narration is not, by itself, a dialogue.
            // Keep direct-speech paragraphs and narration paragraphs that actually
            // contain a quoted/dash-delimited utterance; discard plain prose such
            // as "он сказал, что вернётся".
            val isRelevant = paragraph.isNotEmpty() && (
                isDialogueLine(paragraph) ||
                    (hasQuotedSpeech && hasSpeechVerb(paragraph)) ||
                    (hasDashDialogue && (hasSpeechVerb(paragraph) || voiceHint(paragraph) != null))
                )
            if (isRelevant) sourceIndex to paragraph else null
        }

        val findings = candidates.map { (_, paragraph) -> analyzeParagraph(paragraph) }.toMutableList()

        // A named vocative in the preceding attributed paragraph can identify the
        // likely respondent in the next dialogue paragraph. It never changes the
        // preceding speaker and is deliberately assigned medium confidence.
        for (index in 1 until findings.size) {
            val current = findings[index]
            val previous = findings[index - 1]
            // Do not carry a speaker across an intervening narration paragraph.
            if (candidates[index].first != candidates[index - 1].first + 1) continue
            if (current.speaker != null || !isDialogueLine(current.fragment)) continue
            val addressedName = previous.addressedTo ?: continue
            val profile = characters.firstOrNull { normalize(it.name) == normalize(addressedName) }
                ?: continue
            if (profile.voice.isBlank() || profile.voice.equals("не задан", ignoreCase = true)) continue

            findings[index] = current.copy(
                speaker = profile.name,
                voice = profile.voice,
                confidence = 0.68f,
                reason = "Вероятный ответ на обращение к ${profile.name} в предыдущем фрагменте; проверьте вручную"
            )
        }

        // Some books identify a voice only a few dialogue turns later, for
        // example first write "a female voice sounded outside", then later
        // "Niko's call was answered by Nurina's voice". Use only a short
        // forward window, require matching gender, avoid a conflicting
        // head/external location, and keep confidence deliberately low.
        for (index in findings.indices) {
            val current = findings[index]
            if (current.speaker != null || current.voice == null || !current.fragment.contains("голос", true)) continue
            val location = inferredVoiceLocation(findings, index)
            val end = (index + 15).coerceAtMost(findings.lastIndex)
            var inferred: CharacterProfile? = null
            for (next in index + 1..end) {
                val candidate = findings[next]
                val candidateName = candidate.speaker ?: continue
                val profile = characters.firstOrNull { normalize(it.name) == normalize(candidateName) } ?: continue
                if (!sameVoiceGender(profile, current.voice)) continue
                val candidateLocation = inferredVoiceLocation(findings, next)
                if (location != null && candidateLocation != null && location != candidateLocation) continue
                inferred = profile
                break
            }
            if (inferred != null) {
                findings[index] = current.copy(
                    speaker = inferred.name,
                    confidence = 0.62f,
                    reason = "Предположительный владелец голоса по последующему авторскому указанию; обязательно проверьте вручную"
                )
            }
        }
        return findings
    }
}
