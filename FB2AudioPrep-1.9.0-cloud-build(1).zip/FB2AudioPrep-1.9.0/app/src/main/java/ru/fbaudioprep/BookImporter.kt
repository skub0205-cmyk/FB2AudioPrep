package ru.fbaudioprep

import android.content.ContentResolver
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

object BookImporter {
    data class ImportedBook(
        val title: String,
        val text: String,
        val sourceName: String,
        val isFb2: Boolean,
        val originalBytes: ByteArray,
        val importNote: String
    )

    private data class ArchiveCandidate(val name: String, val bytes: ByteArray)
    private data class ArchiveSelection(val candidate: ArchiveCandidate, val candidateCount: Int)

    fun read(resolver: ContentResolver, uri: Uri, name: String): ImportedBook {
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Не удалось открыть файл")
        val selection = if (name.endsWith(".zip", true)) unzip(bytes) else ArchiveSelection(ArchiveCandidate(name, bytes), 1)
        val selected = selection.candidate
        val isFb2 = selected.name.endsWith(".fb2", true)
        val decoded = if (isFb2) null else BookImportSupport.decodeText(selected.bytes)
        val text = if (isFb2) fb2(selected.bytes) else {
            if (!selected.name.endsWith(".txt", true)) error("Нужен TXT, FB2 или ZIP с TXT/FB2")
            decoded!!.text
        }
        val note = buildList {
            if (selected.name != name) add("Из ZIP выбран файл: ${selected.name} (подходящих файлов: ${selection.candidateCount})")
            if (decoded != null) add("Кодировка TXT: ${decoded.note}")
        }.joinToString("\n")
        return ImportedBook(name, text, selected.name, isFb2, selected.bytes, note)
    }

    /** Selects one archive member deterministically: FB2 first, then shallowest path, then name. */
    private fun unzip(bytes: ByteArray): ArchiveSelection {
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            var best: ArchiveCandidate? = null
            var candidateCount = 0
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && isSupportedBook(entry.name)) {
                    candidateCount++
                    if (best == null || BookImportSupport.compareArchiveNames(entry.name, best.name) < 0) {
                        best = ArchiveCandidate(entry.name, readCurrentEntry(zip))
                    } else {
                        zip.closeEntry()
                    }
                } else {
                    zip.closeEntry()
                }
                entry = zip.nextEntry
            }
            val selected = best ?: error("В ZIP не найден FB2 или TXT")
            return ArchiveSelection(selected, candidateCount)
        }
    }

    // Read only the currently selected ZIP member and guard against unexpectedly huge entries.
    private fun readCurrentEntry(zip: ZipInputStream): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        val maxBytes = 128L * 1024L * 1024L
        var total = 0L
        while (true) {
            val count = zip.read(buffer)
            if (count < 0) break
            total += count
            require(total <= maxBytes) { "Файл внутри ZIP превышает ограничение 128 МБ" }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun isSupportedBook(name: String): Boolean =
        name.endsWith(".fb2", true) || name.endsWith(".txt", true)

    /** XML Pull Parser detects BOM and the encoding declaration itself when encoding is null. */
    private fun fb2(bytes: ByteArray): String {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), null)
        val output = StringBuilder()
        val paragraphTags = setOf("p", "subtitle", "v", "text-author")
        var activeDepth = -1
        var paragraph = StringBuilder()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    if (activeDepth < 0 && parser.name.lowercase() in paragraphTags) {
                        activeDepth = parser.depth
                        paragraph = StringBuilder()
                    }
                }
                XmlPullParser.TEXT, XmlPullParser.CDSECT -> if (activeDepth >= 0) paragraph.append(parser.text)
                XmlPullParser.END_TAG -> if (activeDepth == parser.depth) {
                    val value = paragraph.toString().replace(Regex("\\s+"), " ").trim()
                    if (value.isNotEmpty()) output.append(value).append("\n\n")
                    activeDepth = -1
                }
            }
            event = parser.next()
        }
        return output.toString().trim()
    }

}
