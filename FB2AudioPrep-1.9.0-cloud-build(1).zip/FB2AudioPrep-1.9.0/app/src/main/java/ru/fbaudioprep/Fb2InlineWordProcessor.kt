package ru.fbaudioprep

/**
 * Accentuates words in an XML fragment while allowing a word to cross FB2 inline tags,
 * e.g. ко<emphasis>ро</emphasis>ва. Markup and entity spellings are retained verbatim.
 */
internal class Fb2InlineWordProcessor(private val engine: AccentEngine) {
    data class Result(
        val xml: String,
        val changedWords: Int,
        val unknownWords: List<String>,
        val alreadyAccentedWords: Int,
        val processedWords: Int
    )

    private data class Piece(val raw: String, val logical: String = "", val markup: Boolean = false)

    private val inlineTags = setOf(
        "a", "emphasis", "strong", "strikethrough", "sub", "sup", "style", "span", "code"
    )

    fun process(fragment: String): Result {
        val output = StringBuilder(fragment.length + 32)
        val pending = ArrayList<Piece>()
        val unknown = linkedSetOf<String>()
        var changed = 0
        var already = 0
        var processed = 0

        fun flushWord() {
            if (pending.isEmpty()) return
            val logicalWord = pending.asSequence().filter { !it.markup }.joinToString("") { it.logical }
            if (logicalWord.isEmpty()) {
                pending.forEach { output.append(it.raw) }
                pending.clear()
                return
            }
            val result = engine.process(logicalWord)
            changed += result.changedWords
            already += result.alreadyAccentedWords
            unknown.addAll(result.unknownWords)
            processed++

            if (result.changedWords == 0) {
                pending.forEach { output.append(it.raw) }
            } else {
                // Map stress by letter index, not UTF-16 character count: decomposed
                // Cyrillic letters may contain one or more combining marks (е + diaeresis).
                val markAfterLetterCounts = linkedSetOf<Int>()
                var targetLetterCount = 0
                result.text.forEach { ch ->
                    when {
                        ch == AccentEngine.ACUTE -> markAfterLetterCounts.add(targetLetterCount)
                        ch.isLetter() -> targetLetterCount++
                    }
                }

                fun isCombiningMark(ch: Char): Boolean {
                    val type = Character.getType(ch)
                    return type == Character.NON_SPACING_MARK.toInt() ||
                        type == Character.COMBINING_SPACING_MARK.toInt() ||
                        type == Character.ENCLOSING_MARK.toInt()
                }

                fun nextLogicalCharAfter(pieceIndex: Int, charIndex: Int): Char? {
                    for (index in pieceIndex until pending.size) {
                        val candidate = pending[index]
                        if (candidate.markup) continue
                        val from = if (index == pieceIndex) charIndex else 0
                        if (from < candidate.logical.length) return candidate.logical[from]
                    }
                    return null
                }

                var sourceLetterCount = 0
                var accentWaitingForCombiningMarks = false
                pending.forEachIndexed { pieceIndex, piece ->
                    if (piece.markup) {
                        output.append(piece.raw)
                    } else {
                        // Every non-markup Piece currently represents one source character
                        // or one decoded numeric XML entity; retain its original spelling.
                        val ch = piece.logical.firstOrNull()
                        if (ch != null && accentWaitingForCombiningMarks && !isCombiningMark(ch)) {
                            output.append(AccentEngine.ACUTE)
                            accentWaitingForCombiningMarks = false
                        }
                        output.append(piece.raw)
                        if (ch != null) {
                            when {
                                ch.isLetter() -> {
                                    sourceLetterCount++
                                    if (sourceLetterCount in markAfterLetterCounts) {
                                        val next = nextLogicalCharAfter(pieceIndex, 1)
                                        if (next != null && isCombiningMark(next)) {
                                            accentWaitingForCombiningMarks = true
                                        } else {
                                            output.append(AccentEngine.ACUTE)
                                        }
                                    }
                                }
                                isCombiningMark(ch) && accentWaitingForCombiningMarks -> {
                                    val next = nextLogicalCharAfter(pieceIndex, 1)
                                    if (next == null || !isCombiningMark(next)) {
                                        output.append(AccentEngine.ACUTE)
                                        accentWaitingForCombiningMarks = false
                                    }
                                }
                            }
                        }
                    }
                }
                if (accentWaitingForCombiningMarks) output.append(AccentEngine.ACUTE)
            }
            pending.clear()
        }

        fun isWordChar(ch: Char): Boolean = ch.isLetter() ||
            Character.getType(ch) == Character.NON_SPACING_MARK.toInt() ||
            Character.getType(ch) == Character.COMBINING_SPACING_MARK.toInt()

        fun nextLogicalChar(from: Int): Char? {
            var p = from
            while (p < fragment.length) {
                if (fragment[p] == '<') {
                    val end = findTagEnd(fragment, p)
                    if (end < 0) return null
                    val tag = fragment.substring(p, end + 1)
                    val parsed = parseTag(tag)
                    if (parsed == null || parsed.first !in inlineTags) return null
                    p = end + 1
                    continue
                }
                if (fragment[p] == '&') {
                    val entity = readEntity(fragment, p)
                    return entity?.second?.firstOrNull()
                }
                return fragment[p]
            }
            return null
        }

        var i = 0
        while (i < fragment.length) {
            when (fragment[i]) {
                '<' -> {
                    val end = findTagEnd(fragment, i)
                    if (end < 0) {
                        flushWord()
                        output.append(fragment.substring(i))
                        break
                    }
                    val raw = fragment.substring(i, end + 1)
                    val parsed = parseTag(raw)
                    if (parsed != null && parsed.first in inlineTags) {
                        if (pending.isNotEmpty()) pending.add(Piece(raw, markup = true)) else output.append(raw)
                    } else {
                        flushWord()
                        output.append(raw)
                    }
                    i = end + 1
                }
                '&' -> {
                    val entity = readEntity(fragment, i)
                    if (entity == null) {
                        flushWord()
                        output.append(fragment[i])
                        i++
                    } else {
                        val (endExclusive, decoded) = entity
                        if (decoded.length == 1 && (isWordChar(decoded[0]) || decoded[0] == AccentEngine.ACUTE)) {
                            pending.add(Piece(fragment.substring(i, endExclusive), decoded))
                        } else {
                            flushWord()
                            output.append(fragment, i, endExclusive)
                        }
                        i = endExclusive
                    }
                }
                else -> {
                    val ch = fragment[i]
                    val isHyphenInWord = (ch == '-' || ch == '‑') && pending.isNotEmpty() &&
                        pending.lastOrNull { !it.markup }?.logical?.lastOrNull()?.let { it.isLetter() } == true &&
                        nextLogicalChar(i + 1)?.isLetter() == true
                    if (isWordChar(ch) || isHyphenInWord) {
                        pending.add(Piece(ch.toString(), ch.toString()))
                    } else {
                        flushWord()
                        output.append(ch)
                    }
                    i++
                }
            }
        }
        flushWord()
        return Result(output.toString(), changed, unknown.toList(), already, processed)
    }

    private fun findTagEnd(xml: String, start: Int): Int {
        var quote: Char? = null
        var p = start + 1
        while (p < xml.length) {
            val ch = xml[p]
            if (quote != null) {
                if (ch == quote) quote = null
            } else when (ch) {
                '\'', '"' -> quote = ch
                '>' -> return p
            }
            p++
        }
        return -1
    }

    private fun parseTag(tag: String): Pair<String, Boolean>? {
        if (tag.length < 3 || tag[0] != '<' || tag[1] == '!' || tag[1] == '?') return null
        var p = if (tag[1] == '/') 2 else 1
        while (p < tag.length && tag[p].isWhitespace()) p++
        val start = p
        while (p < tag.length && !tag[p].isWhitespace() && tag[p] != '/' && tag[p] != '>') p++
        if (p == start) return null
        return tag.substring(start, p).substringAfterLast(':').lowercase() to (tag[1] == '/')
    }

    private fun readEntity(value: String, start: Int): Pair<Int, String>? {
        val semi = value.indexOf(';', start + 1)
        if (semi < 0 || semi - start > 32) return null
        val name = value.substring(start + 1, semi)
        val decoded = when {
            name.equals("amp", true) -> "&"
            name.equals("lt", true) -> "<"
            name.equals("gt", true) -> ">"
            name.equals("apos", true) -> "'"
            name.equals("quot", true) -> "\""
            name.startsWith("#x", true) -> name.substring(2).toIntOrNull(16)?.let { String(Character.toChars(it)) }
            name.startsWith("#") -> name.substring(1).toIntOrNull()?.let { String(Character.toChars(it)) }
            else -> null // Unknown DTD entities are preserved as a word boundary.
        } ?: return null
        return (semi + 1) to decoded
    }
}
