package ru.fbaudioprep

import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets
import java.util.Locale

/** Result of an in-place-safe FB2 text transformation. */
data class Fb2AccentResult(
    val xml: ByteArray,
    val changedWords: Int,
    val unknownWords: List<String>,
    val alreadyAccentedWords: Int,
    val processedWords: Int
)

/**
 * Accents only character data inside FB2 <body> elements. Words may span supported inline tags.
 * This is a lexical XML pass rather than parse/serialize: declarations, namespaces,
 * whitespace, inline markup, links, notes, binary images and entity references are retained
 * (apart from the selected text characters that receive accent marks).
 * No DTD or network resource is loaded.
 */
object Fb2Processor {
    private data class Decoded(val text: String, val charset: Charset, val bom: ByteArray)

    fun accentuate(source: ByteArray, engine: AccentEngine): Fb2AccentResult {
        val decoded = decodeXml(source)
        val input = decoded.text
        val output = StringBuilder(input.length + 128)
        val unknown = linkedSetOf<String>()
        var changed = 0
        var already = 0
        var processedWords = 0
        var bodyDepth = 0
        var i = 0
        val bodyFragment = StringBuilder()
        val inlineProcessor = Fb2InlineWordProcessor(engine)
        val inlineTags = setOf("a", "emphasis", "strong", "strikethrough", "sub", "sup", "style", "span", "code")

        fun flushBodyFragment() {
            if (bodyFragment.isEmpty()) return
            val result = inlineProcessor.process(bodyFragment.toString())
            output.append(result.xml)
            changed += result.changedWords
            already += result.alreadyAccentedWords
            unknown.addAll(result.unknownWords)
            processedWords += result.processedWords
            bodyFragment.setLength(0)
        }

        while (i < input.length) {
            if (input[i] != '<') {
                val nextTag = input.indexOf('<', i).let { if (it < 0) input.length else it }
                val rawText = input.substring(i, nextTag)
                if (bodyDepth > 0) bodyFragment.append(rawText) else output.append(rawText)
                i = nextTag
                continue
            }

            when {
                input.startsWith("<![CDATA[", i) -> {
                    flushBodyFragment()
                    val contentStart = i + 9
                    val end = input.indexOf("]]>", contentStart)
                    if (end < 0) {
                        output.append(input.substring(i))
                        i = input.length
                    } else {
                        val content = input.substring(contentStart, end)
                        if (bodyDepth > 0) {
                            val result = engine.process(content)
                            changed += result.changedWords
                            already += result.alreadyAccentedWords
                            unknown.addAll(result.unknownWords)
                            processedWords++
                            if (decoded.charset.newEncoder().canEncode(AccentEngine.ACUTE)) {
                                output.append("<![CDATA[").append(result.text).append("]]>")
                            } else {
                                // Character references are not interpreted inside CDATA.
                                // Convert only this section to escaped XML text so U+0301
                                // can be represented numerically without changing its value.
                                val escaped = result.text
                                    .replace("&", "&amp;")
                                    .replace("<", "&lt;")
                                    .replace(">", "&gt;")
                                    .replace(AccentEngine.ACUTE.toString(), "&#769;")
                                output.append(escaped)
                            }
                        } else {
                            output.append("<![CDATA[").append(content).append("]]>")
                        }
                        i = end + 3
                    }
                }
                input.startsWith("<!--", i) -> {
                    flushBodyFragment()
                    val end = input.indexOf("-->", i + 4)
                    val stop = if (end < 0) input.length else end + 3
                    output.append(input, i, stop)
                    i = stop
                }
                input.startsWith("<?", i) -> {
                    flushBodyFragment()
                    val end = input.indexOf("?>", i + 2)
                    val stop = if (end < 0) input.length else end + 2
                    output.append(input, i, stop)
                    i = stop
                }
                input.startsWith("<!", i) -> {
                    flushBodyFragment()
                    val stop = declarationEnd(input, i)
                    output.append(input, i, stop)
                    i = stop
                }
                else -> {
                    val stop = tagEnd(input, i)
                    if (stop < 0) {
                        flushBodyFragment()
                        output.append(input.substring(i))
                        i = input.length
                    } else {
                        val tag = input.substring(i, stop + 1)
                        val parsed = parseTag(tag)
                        val transparentInline = bodyDepth > 0 && parsed != null && parsed.first in inlineTags
                        if (transparentInline) {
                            bodyFragment.append(tag)
                        } else {
                            flushBodyFragment()
                            output.append(tag)
                        }
                        if (parsed != null && parsed.first == "body") {
                            if (parsed.second) bodyDepth = (bodyDepth - 1).coerceAtLeast(0)
                            else if (!parsed.third) bodyDepth++
                        }
                        i = stop + 1
                    }
                }
            }
        }
        flushBodyFragment()

        val outputText = output.toString()
        // U+0301 is not representable in legacy single-byte encodings such as windows-1251.
        // A numeric XML character reference has identical parsed text and keeps the original encoding.
        val encodableText = if (decoded.charset.newEncoder().canEncode(AccentEngine.ACUTE)) {
            outputText
        } else {
            outputText.replace(AccentEngine.ACUTE.toString(), "&#769;")
        }
        val transformed = encodableText.toByteArray(decoded.charset)
        val resultBytes = if (decoded.bom.isEmpty()) transformed else decoded.bom + transformed
        return Fb2AccentResult(resultBytes, changed, unknown.toList(), already, processedWords)
    }

    /** Returns (local tag name, is closing tag, is self-closing tag). */
    private fun parseTag(tag: String): Triple<String, Boolean, Boolean>? {
        if (tag.length < 3 || tag[0] != '<' || tag[1] == '!' || tag[1] == '?') return null
        var p = 1
        val closing = tag[p] == '/'
        if (closing) p++
        while (p < tag.length && tag[p].isWhitespace()) p++
        val start = p
        while (p < tag.length && !tag[p].isWhitespace() && tag[p] != '/' && tag[p] != '>') p++
        if (p == start) return null
        val qualified = tag.substring(start, p)
        val local = qualified.substringAfterLast(':').lowercase(Locale.ROOT)
        var q = tag.length - 2
        while (q >= 0 && tag[q].isWhitespace()) q--
        val selfClosing = !closing && q >= 0 && tag[q] == '/'
        return Triple(local, closing, selfClosing)
    }

    /** Finds a tag end while respecting quotes in attributes. */
    private fun tagEnd(xml: String, start: Int): Int {
        var quote: Char? = null
        var p = start + 1
        while (p < xml.length) {
            val ch = xml[p]
            if (quote != null) {
                if (ch == quote) quote = null
            } else when (ch) {
                '\'', '"' -> quote = ch
                '>' -> return p
            }
            p++
        }
        return -1
    }

    /** Handles a DOCTYPE internal subset without interpreting or fetching it. */
    private fun declarationEnd(xml: String, start: Int): Int {
        var quote: Char? = null
        var subsetDepth = 0
        var p = start + 2
        while (p < xml.length) {
            val ch = xml[p]
            if (quote != null) {
                if (ch == quote) quote = null
            } else when (ch) {
                '\'', '"' -> quote = ch
                '[' -> subsetDepth++
                ']' -> if (subsetDepth > 0) subsetDepth--
                '>' -> if (subsetDepth == 0) return p + 1
            }
            p++
        }
        return xml.length
    }

    private fun decodeXml(bytes: ByteArray): Decoded {
        val bomAndCharset = when {
            bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte() ->
                Triple(3, StandardCharsets.UTF_8, bytes.copyOfRange(0, 3))
            bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() ->
                Triple(2, Charset.forName("UTF-16LE"), bytes.copyOfRange(0, 2))
            bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() ->
                Triple(2, Charset.forName("UTF-16BE"), bytes.copyOfRange(0, 2))
            else -> Triple(0, null, ByteArray(0))
        }
        val offset = bomAndCharset.first
        val charset = bomAndCharset.second ?: run {
            val prefix = bytes.copyOfRange(0, minOf(bytes.size, 256)).toString(StandardCharsets.ISO_8859_1)
            val declared = Regex("encoding\\s*=\\s*['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE)
                .find(prefix)?.groupValues?.getOrNull(1)
            if (declared.isNullOrBlank()) StandardCharsets.UTF_8 else Charset.forName(declared)
        }
        val text = bytes.copyOfRange(offset, bytes.size).toString(charset)
        return Decoded(text, charset, bomAndCharset.third)
    }
}
