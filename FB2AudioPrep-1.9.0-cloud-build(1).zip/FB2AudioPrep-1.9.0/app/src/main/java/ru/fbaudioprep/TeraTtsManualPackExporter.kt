package ru.fbaudioprep

import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Creates a human-readable handoff pack for configuring characters in TeraTTS.
 * This is deliberately NOT advertised as an import file: TeraTTS 1.59 keeps
 * character settings in app-private, book-scoped SharedPreferences and no
 * supported external import endpoint has been confirmed.
 */
object TeraTtsManualPackExporter {
    fun encode(
        bookName: String,
        characters: List<CharacterProfile>,
        findings: List<DialogueFinding>
    ): ByteArray {
        val output = ByteArrayOutputStream()
        ZipOutputStream(output, StandardCharsets.UTF_8).use { zip ->
            add(zip, "00-ИНСТРУКЦИЯ.txt", instructions(bookName, characters, findings))
            add(zip, "01-ПЕРСОНАЖИ.csv", characterCsv(characters))
            add(zip, "02-ДИАЛОГИ.csv", dialogueCsv(findings))
        }
        return output.toByteArray()
    }

    private fun instructions(
        bookName: String,
        characters: List<CharacterProfile>,
        findings: List<DialogueFinding>
    ): String = buildString {
        appendLine("FB2 AudioPrep — карта настройки персонажей TeraTTS 1.59")
        appendLine("Книга: $bookName")
        appendLine("Персонажей в карте: ${characters.size}")
        appendLine("Фрагментов диалога: ${findings.size}")
        appendLine()
        appendLine("ВАЖНО: этот ZIP — справочный набор для ручной настройки, НЕ файл импорта TeraTTS.")
        appendLine("В APK TeraTTS 1.59 не подтверждён внешний импорт персонажей/голосов.")
        appendLine("Не переименовывайте CSV в JSON и не импортируйте его как словарь ударений.")
        appendLine()
        appendLine("Как использовать:")
        appendLine("1. Откройте эту же книгу в TeraTTS и перейдите к чтению по полям/персонажам.")
        appendLine("2. Сверьте список персонажей с файлом 01-ПЕРСОНАЖИ.csv.")
        appendLine("3. Для каждого персонажа вручную задайте мужской или женский голос в TeraTTS.")
        appendLine("4. Используйте псевдонимы из CSV только если TeraTTS показывает отдельные дубли одного героя.")
        appendLine("5. Фрагменты с неопределённым говорящим проверьте по файлу 02-ДИАЛОГИ.csv.")
        appendLine("6. Не назначайте голос по обращению: имя после реплики может быть адресатом, а не говорящим.")
        appendLine()
        appendLine("Обозначения голоса в CSV — это пол, указанный/подтверждённый в FB2 AudioPrep.")
        appendLine("Конкретный голос (например, F1 или M1) выбирается уже в TeraTTS.")
        appendLine()
        appendLine("Проверка на примерах:")
        appendLine("- «Нико! Нико, мать твою!» — обращение к Нико; женский голос указан автором; говорящий не выдумывается.")
        appendLine("- «Нико, добро пожаловать!» — Нико является адресатом, не говорящим.")
        appendLine("- «…выдал отчёт ИмИн» — ИмИн определяется как говорящий по авторской ремарке.")
    }

    private fun characterCsv(characters: List<CharacterProfile>): String = buildString {
        append('\uFEFF') // UTF-8 BOM helps spreadsheet apps detect Cyrillic CSV.
        appendLine("Имя;Псевдонимы;Пол голоса;Рекомендация")
        characters.sortedBy { it.name.lowercase() }.forEach { profile ->
            val gender = when (profile.voice.lowercase()) {
                "женский", "f", "female" -> "женский"
                "мужской", "m", "male" -> "мужской"
                else -> "не задан"
            }
            val recommendation = when (gender) {
                "женский" -> "В TeraTTS выбрать женский голос"
                "мужской" -> "В TeraTTS выбрать мужской голос"
                else -> "Сначала уточнить пол голоса"
            }
            appendLine(listOf(profile.name, profile.aliases.joinToString(", "), gender, recommendation).joinToString(";") { csv(it) })
        }
    }

    private fun dialogueCsv(findings: List<DialogueFinding>): String = buildString {
        append('\uFEFF')
        appendLine("№;Говорящий;Обращение;Пол/подсказка голоса;Уверенность, %;Ручная правка;Статус;Основание;Фрагмент")
        findings.forEachIndexed { index, finding ->
            val manual = if (finding.reason.contains("пользователем", ignoreCase = true)) "да" else "нет"
            val status = when {
                manual == "да" -> "подтверждено вручную"
                finding.speaker != null && finding.confidence < 0.7f -> "предположение — проверить"
                finding.speaker != null -> "определено по тексту"
                else -> "говорящий не определён"
            }
            val row = listOf(
                (index + 1).toString(),
                finding.speaker.orEmpty(),
                finding.addressedTo.orEmpty(),
                finding.voice.orEmpty(),
                (finding.confidence * 100).toInt().toString(),
                manual,
                status,
                finding.reason,
                finding.fragment
            )
            appendLine(row.joinToString(";") { csv(it) })
        }
    }

    private fun csv(value: String): String = "\"${value.replace("\"", "\"\"").replace("\r", " ").replace("\n", " ")}\""

    private fun add(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(StandardCharsets.UTF_8))
        zip.closeEntry()
    }
}
