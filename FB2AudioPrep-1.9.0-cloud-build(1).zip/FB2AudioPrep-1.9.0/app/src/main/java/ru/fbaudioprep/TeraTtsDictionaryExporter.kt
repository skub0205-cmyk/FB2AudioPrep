package ru.fbaudioprep

import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/** Builds the JSON object accepted by TeraTTS bulk accent-dictionary import. */
object TeraTtsDictionaryExporter {
    fun encode(builtIn: Map<String, String>, personal: Map<String, String>): String {
        // Normalize keys for merging so a personal entry overrides a built-in entry
        // even if the two source keys differ only by capitalization or an acute mark.
        val merged = LinkedHashMap<String, Pair<String, String>>()
        builtIn.forEach { (word, accented) ->
            merged[normalizeKey(word)] = wordWithoutAcute(word) to accented
        }
        personal.forEach { (word, accented) ->
            merged[normalizeKey(word)] = wordWithoutAcute(word) to accented
        }

        val json = JSONObject()
        merged.values
            .sortedBy { it.first.lowercase(Locale.ROOT) }
            .forEach { (word, accented) -> json.put(word, accented) }
        return json.toString(2)
    }

    private fun normalizeKey(value: String): String =
        Normalizer.normalize(wordWithoutAcute(value), Normalizer.Form.NFC).lowercase(Locale.ROOT)

    private fun wordWithoutAcute(value: String): String = value.replace("\u0301", "")
}
