package ru.fbaudioprep

import org.json.JSONArray
import org.json.JSONObject

object CharacterStore {
    fun decode(raw: String): List<CharacterProfile> {
        val array = JSONArray(raw)
        val result = mutableListOf<CharacterProfile>()
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            val aliasesJson = item.optJSONArray("aliases") ?: JSONArray()
            val aliases = (0 until aliasesJson.length()).map { aliasesJson.getString(it) }
            result.add(CharacterProfile(
                item.getString("name"),
                aliases,
                item.optString("voice", "не задан")
            ))
        }
        return result
    }

    fun encode(profiles: List<CharacterProfile>): String {
        val array = JSONArray()
        profiles.forEach { profile ->
            val item = JSONObject()
            item.put("name", profile.name)
            item.put("aliases", JSONArray(profile.aliases))
            item.put("voice", profile.voice)
            array.put(item)
        }
        return array.toString()
    }
}
