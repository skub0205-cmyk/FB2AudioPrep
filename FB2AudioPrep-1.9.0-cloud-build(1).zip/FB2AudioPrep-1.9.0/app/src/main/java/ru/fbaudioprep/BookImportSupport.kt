package ru.fbaudioprep

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.util.Locale

/** Pure Kotlin helpers for robust offline TXT decoding and deterministic ZIP selection. */
object BookImportSupport {
    data class DecodedText(
        val text: String,
        val charsetName: String,
        val hadBom: Boolean,
        val note: String
    )

    /**
     * Decodes common ebook text encodings without silently turning Windows-1251 into mojibake.
     * Priority: BOM, BOM-less UTF-16 XML/text signature, strict UTF-8, then Windows-1251.
     */
    fun decodeText(bytes: ByteArray): DecodedText {
        if (startsWith(bytes, 0xEF, 0xBB, 0xBF)) {
            return decoded(bytes, 3, StandardCharsets.UTF_8, true, "UTF-8 (BOM)")
        }
        if (startsWith(bytes, 0xFF, 0xFE)) {
            return decoded(bytes, 2, Charset.forName("UTF-16LE"), true, "UTF-16LE (BOM)")
        }
        if (startsWith(bytes, 0xFE, 0xFF)) {
            return decoded(bytes, 2, Charset.forName("UTF-16BE"), true, "UTF-16BE (BOM)")
        }
        if (looksLikeUtf16Le(bytes)) {
            return decoded(bytes, 0, Charset.forName("UTF-16LE"), false, "UTF-16LE (определено по сигнатуре)")
        }
        if (looksLikeUtf16Be(bytes)) {
            return decoded(bytes, 0, Charset.forName("UTF-16BE"), false, "UTF-16BE (определено по сигнатуре)")
        }

        try {
            val utf8 = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString()
            return DecodedText(utf8, "UTF-8", false, "UTF-8 (без BOM)")
        } catch (_: CharacterCodingException) {
            val cp1251 = Charset.forName("windows-1251")
            // Windows-1251 has one undefined byte (0x98) in common JVM mappings. Replace only
            // that invalid byte rather than failing to open an otherwise readable legacy book.
            val text = cp1251.newDecoder()
                .onMalformedInput(CodingErrorAction.REPLACE)
                .onUnmappableCharacter(CodingErrorAction.REPLACE)
                .replaceWith("�")
                .decode(ByteBuffer.wrap(bytes)).toString()
            return DecodedText(
                text,
                "windows-1251",
                false,
                "Windows-1251 (предположительно: файл не является корректным UTF-8)"
            )
        }
    }

    /** Negative means left should be selected before right. FB2 wins over TXT. */
    fun compareArchiveNames(left: String, right: String): Int {
        fun rank(name: String): Triple<Int, Int, String> {
            val normalized = name.replace('\\', '/')
            val extensionRank = if (normalized.endsWith(".fb2", true)) 0 else 1
            val depth = normalized.count { it == '/' }
            return Triple(extensionRank, depth, normalized.lowercase(Locale.ROOT))
        }
        val a = rank(left)
        val b = rank(right)
        return compareValuesBy(a, b, { it.first }, { it.second }, { it.third })
    }

    private fun decoded(
        bytes: ByteArray,
        offset: Int,
        charset: Charset,
        bom: Boolean,
        note: String
    ): DecodedText = DecodedText(
        charset.decode(ByteBuffer.wrap(bytes, offset, bytes.size - offset)).toString(),
        charset.name(),
        bom,
        note
    )

    private fun startsWith(bytes: ByteArray, vararg values: Int): Boolean =
        bytes.size >= values.size && values.indices.all { (bytes[it].toInt() and 0xFF) == values[it] }

    private fun looksLikeUtf16Le(bytes: ByteArray): Boolean =
        bytes.size >= 4 && bytes[0] == '<'.code.toByte() && bytes[1] == 0.toByte() &&
            (bytes[2] == '?'.code.toByte() || bytes[2] == 'F'.code.toByte()) && bytes[3] == 0.toByte()

    private fun looksLikeUtf16Be(bytes: ByteArray): Boolean =
        bytes.size >= 4 && bytes[0] == 0.toByte() && bytes[1] == '<'.code.toByte() &&
            bytes[2] == 0.toByte() && (bytes[3] == '?'.code.toByte() || bytes[3] == 'F'.code.toByte())
}
