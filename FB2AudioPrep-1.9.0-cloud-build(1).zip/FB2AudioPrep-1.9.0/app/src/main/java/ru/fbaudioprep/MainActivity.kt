package ru.fbaudioprep

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import org.json.JSONObject

class MainActivity : Activity() {
    private val openId = 101
    private val saveReportId = 102
    private val saveTextId = 103
    private val exportDictionaryId = 104
    private val saveFb2Id = 105
    private val exportTeraManualPackId = 106
    private val prefsName = "fb2audioprep_dictionary"
    private val prefsKey = "entries_json"
    private val characterPrefsName = "fb2audioprep_characters"
    private val characterPrefsKey = "profiles_json"

    private var report = ""
    private var processedText = ""
    private var originalText = ""
    private var sourceName = ""
    private var originalFb2Bytes: ByteArray? = null
    private var processedFb2Bytes: ByteArray? = null
    private var currentBookIsFb2 = false
    private lateinit var status: TextView
    private lateinit var preview: TextView
    private lateinit var accentButton: Button
    private lateinit var saveTextButton: Button
    private lateinit var saveFb2Button: Button
    private lateinit var dictionaryButton: Button
    private lateinit var characterButton: Button
    private lateinit var dialogueButton: Button
    private var dialogueReport = ""
    private var dialogueFindings: List<DialogueFinding> = emptyList()
    private lateinit var reviewDialoguesButton: Button
    private lateinit var teraManualPackButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
        }

        root.addView(TextView(this).apply {
            text = "FB2 AudioPrep 1.9.0"
            textSize = 24f
        })

        status = TextView(this).apply {
            text = "Откройте FB2, TXT или ZIP с книгой."
            textSize = 15f
            setPadding(0, 12, 0, 12)
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Открыть книгу"
            setOnClickListener { openBook() }
        })

        dictionaryButton = Button(this).apply {
            text = "Мой словарь ударений"
            setOnClickListener { showDictionary() }
        }
        root.addView(dictionaryButton)

        root.addView(Button(this).apply {
            text = "Экспорт словаря для TeraTTS"
            setOnClickListener {
                createDocument(exportDictionaryId, "application/json", "TeraTTS-accent-dictionary.json")
            }
        })

        characterButton = Button(this).apply {
            text = "Персонажи и голоса"
            setOnClickListener { showCharacters() }
        }
        root.addView(characterButton)

        dialogueButton = Button(this).apply {
            text = "Проверить диалоги"
            isEnabled = false
            setOnClickListener { analyzeDialogues() }
        }
        root.addView(dialogueButton)

        reviewDialoguesButton = Button(this).apply {
            text = "Проверить и исправить говорящих"
            isEnabled = false
            setOnClickListener { showDialogueReview() }
        }
        root.addView(reviewDialoguesButton)

        teraManualPackButton = Button(this).apply {
            text = "Экспорт справочной карты для ручной настройки TeraTTS (ZIP)"
            isEnabled = false
            setOnClickListener {
                if (loadCharacters().isEmpty()) {
                    Toast.makeText(this@MainActivity, "Сначала добавьте персонажей и назначьте им пол голоса", Toast.LENGTH_LONG).show()
                } else {
                    createDocument(exportTeraManualPackId, "application/zip", "TeraTTS-manual-character-map.zip")
                }
            }
        }
        root.addView(teraManualPackButton)

        accentButton = Button(this).apply {
            text = "Расставить ударения"
            isEnabled = false
            setOnClickListener { accentBook() }
        }
        root.addView(accentButton)

        saveTextButton = Button(this).apply {
            text = "Сохранить обработанный TXT"
            isEnabled = false
            setOnClickListener { createDocument(saveTextId, "text/plain", outputName()) }
        }
        root.addView(saveTextButton)

        saveFb2Button = Button(this).apply {
            text = "Сохранить обработанный FB2"
            isEnabled = false
            setOnClickListener { createDocument(saveFb2Id, "application/xml", outputFb2Name()) }
        }
        root.addView(saveFb2Button)

        root.addView(Button(this).apply {
            text = "Сохранить отчёт TXT"
            setOnClickListener {
                if (report.isBlank()) {
                    Toast.makeText(this@MainActivity, "Сначала откройте книгу", Toast.LENGTH_SHORT).show()
                } else {
                    createDocument(saveReportId, "text/plain", "FB2AudioPrep-report.txt")
                }
            }
        })

        preview = TextView(this).apply {
            textSize = 14f
            setPadding(0, 14, 0, 14)
            text = "Здесь появится предпросмотр книги."
        }
        root.addView(
            ScrollView(this).apply { addView(preview) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
    }

    private fun openBook() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf("text/plain", "application/xml", "application/zip", "application/octet-stream")
            )
        }
        startActivityForResult(intent, openId)
    }

    private fun createDocument(requestCode: Int, mime: String, name: String) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, name)
        }
        startActivityForResult(intent, requestCode)
    }

    private fun outputName(): String {
        val safeName = sourceName.substringAfterLast('/').substringAfterLast('\\')
        val stem = safeName.substringBeforeLast('.', safeName).ifBlank { "book" }
        return "${stem}-accented.txt"
    }

    private fun outputFb2Name(): String {
        val safeName = sourceName.substringAfterLast('/').substringAfterLast('\\')
        val stem = safeName.substringBeforeLast('.', safeName).ifBlank { "book" }
        return "${stem}-accented.fb2"
    }

    @Deprecated("Compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            openId -> load(uri)
            saveReportId -> save(uri, report, "Отчёт сохранён")
            saveTextId -> save(uri, processedText, "Обработанный текст сохранён")
            saveFb2Id -> saveBytes(uri, processedFb2Bytes, "Обработанный FB2 сохранён")
            exportDictionaryId -> save(uri, exportTeraDictionary(), "JSON-словарь ударений для TeraTTS сохранён")
            exportTeraManualPackId -> saveBytes(
                uri,
                TeraTtsManualPackExporter.encode(sourceName, loadCharacters(), dialogueFindings),
                "Карта персонажей сохранена. Это справочный ZIP, не импорт TeraTTS."
            )
        }
    }

    private fun load(uri: Uri) {
        try {
            val name = contentResolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "book"
            val book = BookImporter.read(contentResolver, uri, name)

            sourceName = book.sourceName
            originalText = book.text
            originalFb2Bytes = book.originalBytes.takeIf { book.isFb2 }
            processedFb2Bytes = null
            currentBookIsFb2 = book.isFb2
            processedText = ""
            accentButton.isEnabled = true
            dialogueButton.isEnabled = true
            reviewDialoguesButton.isEnabled = false
            teraManualPackButton.isEnabled = true
            dialogueFindings = emptyList()
            dialogueReport = ""
            saveTextButton.isEnabled = false
            saveFb2Button.isEnabled = false

            report = buildString {
                appendLine("FB2 AudioPrep 1.9.0")
                appendLine("Файл: $name")
                appendLine("Внутренний файл: ${book.sourceName}")
                appendLine("Символов: ${book.text.length}")
                appendLine("Строк: ${book.text.lines().size}")
                if (book.importNote.isNotBlank()) appendLine(book.importNote)
                appendLine()
                appendLine("Книга загружена. Ударения ещё не расставлены.")
            }
            status.text = "Открыто: $name\nФормат: ${if (book.isFb2) "FB2" else "TXT"}\n" +
                "Символов: ${book.text.length}" +
                (if (book.importNote.isNotBlank()) "\n${book.importNote}" else "") +
                "\nМожно запустить обработку ударений."
            preview.text = book.text.take(8000)
        } catch (e: Exception) {
            status.text = "Ошибка открытия: ${e.message}"
            preview.text = ""
            report = ""
            originalText = ""
            processedText = ""
            accentButton.isEnabled = false
            saveTextButton.isEnabled = false
            saveFb2Button.isEnabled = false
            originalFb2Bytes = null
            processedFb2Bytes = null
            currentBookIsFb2 = false
        }
    }

    private fun accentBook() {
        if (originalText.isBlank()) return
        try {
            val engine = AccentEngine(loadBuiltInDictionary(), loadUserDictionary())
            // Keep a plain-text preview for both formats; for FB2 the authoritative export
            // is produced by walking XML body text nodes, leaving metadata and binaries intact.
            val previewResult = engine.process(originalText)
            processedText = previewResult.text
            var changedWords = previewResult.changedWords
            var alreadyAccentedWords = previewResult.alreadyAccentedWords
            var unknownWords = previewResult.unknownWords

            if (currentBookIsFb2) {
                val source = originalFb2Bytes ?: error("Не найдены исходные данные FB2")
                val fb2Result = Fb2Processor.accentuate(source, engine)
                processedFb2Bytes = fb2Result.xml
                changedWords = fb2Result.changedWords
                alreadyAccentedWords = fb2Result.alreadyAccentedWords
                unknownWords = fb2Result.unknownWords
                saveFb2Button.isEnabled = true
                saveTextButton.isEnabled = true
            } else {
                processedFb2Bytes = null
                saveTextButton.isEnabled = true
                saveFb2Button.isEnabled = false
            }

            report = buildString {
                appendLine("FB2 AudioPrep 1.9.0 — отчёт обработки")
                appendLine("Файл: $sourceName")
                appendLine("Формат: ${if (currentBookIsFb2) "FB2" else "TXT"}")
                appendLine("Символов в извлечённом тексте: ${originalText.length}")
                appendLine("Слов с добавленным ударением: $changedWords")
                appendLine("Слов, уже содержащих знак ударения: $alreadyAccentedWords")
                appendLine("Не найдено в словаре (уникальных написаний): ${unknownWords.size}")
                appendLine()
                appendLine("Неизвестные слова — список для проверки и пополнения словаря:")
                unknownWords.forEach { appendLine(it) }
                appendLine()
                if (currentBookIsFb2) {
                    appendLine("Экспорт FB2 сохраняет XML-структуру, метаданные, ссылки, примечания и бинарные блоки.")
                    appendLine("Изменяются только текстовые узлы внутри элементов body.")
                }
                appendLine("Важно: приложение не угадывает ударение для неизвестных слов.")
                appendLine("Проверьте результат перед использованием в TeraTTS.")
            }

            status.text = "Обработка завершена.\nДобавлено ударений: $changedWords\n" +
                "Уже были с ударением: $alreadyAccentedWords\n" +
                "Неизвестных слов: ${unknownWords.size}\n" +
                if (currentBookIsFb2) "Можно сохранить обработанный FB2 или извлечённый TXT." else "Можно сохранить обработанный TXT."
            preview.text = processedText.take(8000)
            Toast.makeText(this, "Обработка завершена", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            status.text = "Ошибка обработки: ${e.message}"
        }
    }

    private fun loadCharacters(): List<CharacterProfile> {
        val raw = getSharedPreferences(characterPrefsName, MODE_PRIVATE)
            .getString(characterPrefsKey, "[]") ?: "[]"
        return CharacterStore.decode(raw)
    }

    private fun saveCharacters(items: List<CharacterProfile>) {
        getSharedPreferences(characterPrefsName, MODE_PRIVATE).edit()
            .putString(characterPrefsKey, CharacterStore.encode(items))
            .apply()
    }

    private fun showCharacters() {
        val items = loadCharacters()
        val labels = items.map { "${it.name} — ${it.voice}" }.toMutableList()
        labels.add(0, "＋ Добавить персонажа")
        AlertDialog.Builder(this)
            .setTitle("Персонажи (${items.size})")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) editCharacter(null)
                else editCharacter(items[which - 1])
            }
            .setPositiveButton("Закрыть", null)
            .show()
    }

    private fun editCharacter(existing: CharacterProfile?) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        val name = EditText(this).apply {
            hint = "Основное имя, например ИмИн"
            setText(existing?.name.orEmpty())
        }
        val aliases = EditText(this).apply {
            hint = "Другие варианты имени через запятую"
            setText(existing?.aliases?.joinToString(", ").orEmpty())
        }
        val voice = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("не задан", "женский", "мужской")
            )
            setSelection(
                listOf("не задан", "женский", "мужской").indexOf(existing?.voice ?: "не задан").coerceAtLeast(0)
            )
        }
        panel.addView(name)
        panel.addView(aliases)
        panel.addView(TextView(this).apply { text = "Голос персонажа" })
        panel.addView(voice)
        val builder = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Новый персонаж" else "Изменить персонажа")
            .setView(panel)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить") { _, _ ->
                val canonical = name.text.toString().trim()
                if (canonical.isBlank()) {
                    Toast.makeText(this, "Введите имя персонажа", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val variants = aliases.text.toString().split(",").map { it.trim() }.filter { it.isNotBlank() }
                val updated = loadCharacters().filterNot { it.name == existing?.name }.toMutableList()
                updated.add(CharacterProfile(canonical, variants, voice.selectedItem.toString()))
                saveCharacters(updated)
                showCharacters()
            }
        if (existing != null) {
            builder.setNeutralButton("Удалить") { _, _ ->
                saveCharacters(loadCharacters().filterNot { it.name == existing.name })
                showCharacters()
            }
        }
        builder.show()
    }

    private fun analyzeDialogues() {
        if (originalText.isBlank()) return
        val analyzed = DialogueAnalyzer(loadCharacters()).analyzeBook(originalText)
        val findings = DialogueCorrectionStore.apply(this, originalText, analyzed)
        dialogueFindings = findings
        reviewDialoguesButton.isEnabled = findings.isNotEmpty()
        val known = findings.count { it.speaker != null }
        val uncertain = findings.size - known
        dialogueReport = buildString {
            appendLine("FB2 AudioPrep 1.9.0 — анализ диалогов")
            appendLine("Файл: $sourceName")
            appendLine("Найдено фрагментов: ${findings.size}")
            appendLine("Определён говорящий: $known")
            appendLine("Требуют проверки: $uncertain")
            appendLine()
            findings.forEachIndexed { index, finding ->
                appendLine("Фрагмент ${index + 1}")
                appendLine("Говорящий: ${finding.speaker ?: "не определён"}")
                appendLine("Обращение: ${finding.addressedTo ?: "не найдено"}")
                appendLine("Голос: ${finding.voice ?: "не определён"}")
                appendLine("Уверенность: ${(finding.confidence * 100).toInt()}%")
                appendLine("Причина: ${finding.reason}")
                appendLine(finding.fragment)
                appendLine()
            }
            appendLine("Важно: это предварительный анализ. Неопределённые реплики не назначаются персонажам автоматически.")
        }
        report = if (report.isBlank()) dialogueReport else report + "\n\n" + dialogueReport
        status.text = "Анализ диалогов завершён.\nФрагментов: ${findings.size}\n" +
            "Говорящий определён: $known\nТребуют ручной проверки: $uncertain\nОтчёт можно сохранить."
        preview.text = dialogueReport.take(8000)
    }

    private fun showDialogueReview() {
        if (dialogueFindings.isEmpty()) {
            Toast.makeText(this, "Сначала запустите анализ диалогов", Toast.LENGTH_SHORT).show()
            return
        }
        val profiles = loadCharacters()
        if (profiles.isEmpty()) {
            AlertDialog.Builder(this)
                .setMessage("Сначала добавьте персонажей и назначьте им голоса.")
                .setPositiveButton("Открыть персонажей") { _, _ -> showCharacters() }
                .setNegativeButton("Закрыть", null)
                .show()
            return
        }
        val labels = dialogueFindings.mapIndexed { index, finding ->
            val who = finding.speaker ?: "не определён"
            val target = finding.addressedTo?.let { " (обращение к $it)" } ?: ""
            val excerpt = finding.fragment.replace('\n', ' ').take(85)
            "${index + 1}. $who$target — $excerpt"
        }
        AlertDialog.Builder(this)
            .setTitle("Реплики для проверки (${dialogueFindings.size})")
            .setItems(labels.toTypedArray()) { _, which -> editFindingSpeaker(which, profiles) }
            .setPositiveButton("Готово") { _, _ -> refreshDialogueReport() }
            .setNeutralButton("Сбросить правки") { _, _ ->
                AlertDialog.Builder(this)
                    .setMessage("Удалить все ручные назначения говорящих для этой книги?")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Сбросить") { _, _ ->
                        DialogueCorrectionStore.clear(this, originalText)
                        analyzeDialogues()
                        Toast.makeText(this, "Ручные назначения сброшены", Toast.LENGTH_SHORT).show()
                    }
                    .show()
            }
            .show()
    }

    private fun editFindingSpeaker(index: Int, profiles: List<CharacterProfile>) {
        val finding = dialogueFindings[index]
        val choices = mutableListOf("Не назначать персонажа")
        choices.addAll(profiles.map { "${it.name} — ${it.voice}" })
        val current = finding.speaker?.let { name -> profiles.indexOfFirst { it.name == name } } ?: -1
        AlertDialog.Builder(this)
            .setTitle("Кто произносит эту реплику?")
            .setMessage(finding.fragment.take(900))
            .setSingleChoiceItems(choices.toTypedArray(), current + 1) { dialog, selected ->
                val selectedProfile = if (selected == 0) null else profiles[selected - 1]
                val corrected = finding.copy(
                    speaker = selectedProfile?.name,
                    voice = selectedProfile?.voice?.takeUnless { it == "не задан" },
                    confidence = if (selectedProfile == null) 0f else 1f,
                    reason = if (selectedProfile == null) "Оставлено без назначения вручную"
                        else "Говорящий назначен пользователем"
                )
                dialogueFindings = dialogueFindings.toMutableList().also { it[index] = corrected }
                DialogueCorrectionStore.save(this, originalText, index, corrected)
                dialog.dismiss()
                showDialogueReview()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun refreshDialogueReport() {
        val findings = dialogueFindings
        val known = findings.count { it.speaker != null }
        dialogueReport = buildString {
            appendLine("FB2 AudioPrep 1.9.0 — проверка диалогов")
            appendLine("Файл: $sourceName")
            appendLine("Фрагментов: ${findings.size}")
            appendLine("Назначен говорящий: $known")
            appendLine("Без назначения: ${findings.size - known}")
            appendLine()
            findings.forEachIndexed { index, finding ->
                appendLine("Фрагмент ${index + 1}")
                appendLine("Говорящий: ${finding.speaker ?: "не определён"}")
                appendLine("Обращение: ${finding.addressedTo ?: "не найдено"}")
                appendLine("Голос: ${finding.voice ?: "не определён"}")
                appendLine("Уверенность: ${(finding.confidence * 100).toInt()}%")
                appendLine("Основание: ${finding.reason}")
                appendLine(finding.fragment)
                appendLine()
            }
        }
        report = buildString {
            appendLine("FB2 AudioPrep 1.9.0")
            appendLine("Файл: $sourceName")
            appendLine("Отчёт по ударениям и диалогам")
            appendLine()
            append(dialogueReport)
        }
        status.text = "Ручная проверка диалогов обновлена.\nНазначено говорящих: $known из ${findings.size}."
        preview.text = dialogueReport.take(8000)
    }

    private fun showDictionary() {
        val entries = loadUserDictionary().toSortedMap(String.CASE_INSENSITIVE_ORDER)
        val labels = entries.map { (word, accented) -> "$word  →  $accented" }.toMutableList()
        labels.add(0, "＋ Добавить слово")

        AlertDialog.Builder(this)
            .setTitle("Мой словарь (${entries.size})")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) showEntryEditor(null, null)
                else {
                    val key = entries.keys.elementAt(which - 1)
                    showEntryActions(key, entries.getValue(key))
                }
            }
            .setPositiveButton("Закрыть", null)
            .show()
    }

    private fun showEntryActions(word: String, accented: String) {
        AlertDialog.Builder(this)
            .setTitle(word)
            .setItems(arrayOf("Изменить", "Удалить")) { _, which ->
                when (which) {
                    0 -> showEntryEditor(word, accented)
                    1 -> AlertDialog.Builder(this)
                        .setMessage("Удалить «$word» из личного словаря?")
                        .setNegativeButton("Отмена", null)
                        .setPositiveButton("Удалить") { _, _ ->
                            val updated = loadUserDictionary().toMutableMap()
                            updated.remove(word)
                            saveUserDictionary(updated)
                            showDictionary()
                        }
                        .show()
                }
            }
            .setNegativeButton("Назад") { _, _ -> showDictionary() }
            .show()
    }

    private fun showEntryEditor(existingWord: String?, existingForm: String?) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        val wordInput = EditText(this).apply {
            hint = "Слово без ударения"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(existingWord.orEmpty())
        }
        val formInput = EditText(this).apply {
            hint = "Форма с ударением, например Ни́ко"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(existingForm.orEmpty())
        }
        panel.addView(wordInput)
        panel.addView(formInput)
        AlertDialog.Builder(this)
            .setTitle(if (existingWord == null) "Новое слово" else "Изменить ударение")
            .setMessage("Поставьте знак ударения над гласной. Используется комбинируемый знак U+0301.")
            .setView(panel)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить", null)
            .create()
            .also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val word = wordInput.text.toString().trim()
                        val form = formInput.text.toString().trim()
                        try {
                            validateEntry(word, form)
                            val updated = loadUserDictionary().toMutableMap()
                            if (existingWord != null) updated.remove(existingWord)
                            updated[word] = form
                            saveUserDictionary(updated)
                            dialog.dismiss()
                            Toast.makeText(this, "Слово сохранено", Toast.LENGTH_SHORT).show()
                            showDictionary()
                        } catch (e: IllegalArgumentException) {
                            Toast.makeText(this, e.message ?: "Проверьте запись", Toast.LENGTH_LONG).show()
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun validateEntry(word: String, form: String) {
        require(word.isNotBlank()) { "Введите слово" }
        require(form.isNotBlank()) { "Введите форму с ударением" }
        require(form.contains('\u0301')) { "В форме нет знака ударения U+0301. Пример: Ни́ко" }
        val normalizedWord = java.text.Normalizer.normalize(
            word.replace("\u0301", ""), java.text.Normalizer.Form.NFC
        ).lowercase(java.util.Locale.ROOT)
        val normalizedForm = java.text.Normalizer.normalize(
            form.replace("\u0301", ""), java.text.Normalizer.Form.NFC
        ).lowercase(java.util.Locale.ROOT)
        require(normalizedWord == normalizedForm) {
            "Форма должна совпадать со словом, меняется только ударение"
        }
    }

    private fun loadUserDictionary(): Map<String, String> {
        val raw = getSharedPreferences(prefsName, MODE_PRIVATE).getString(prefsKey, "{}") ?: "{}"
        val json = JSONObject(raw)
        val result = LinkedHashMap<String, String>()
        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            result[key] = json.getString(key)
        }
        return result
    }

    private fun saveUserDictionary(entries: Map<String, String>) {
        val json = JSONObject()
        entries.forEach { (word, form) -> json.put(word, form) }
        getSharedPreferences(prefsName, MODE_PRIVATE).edit()
            .putString(prefsKey, json.toString())
            .apply()
    }

    private fun exportTeraDictionary(): String =
        TeraTtsDictionaryExporter.encode(loadBuiltInDictionary(), loadUserDictionary())

    private fun loadBuiltInDictionary(): Map<String, String> {
        val jsonText = assets.open("accent_dictionary.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val json = JSONObject(jsonText)
        val result = LinkedHashMap<String, String>()
        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            result[key] = json.getString(key)
        }
        return result
    }

    private fun saveBytes(uri: Uri, bytes: ByteArray?, successMessage: String) {
        try {
            val content = bytes ?: error("Сначала обработайте книгу")
            contentResolver.openOutputStream(uri)?.use { it.write(content) }
                ?: error("Не удалось создать файл")
            Toast.makeText(this, successMessage, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка сохранения: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun save(uri: Uri, text: String, successMessage: String) {
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(text)
            } ?: error("Не удалось создать файл")
            Toast.makeText(this, successMessage, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка сохранения: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
