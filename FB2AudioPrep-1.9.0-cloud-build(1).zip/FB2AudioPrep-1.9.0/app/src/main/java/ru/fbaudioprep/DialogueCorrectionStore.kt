package ru.fbaudioprep

import android.content.Context
import org.json.JSONObject
import java.security.MessageDigest

/** Stores user-confirmed speaker assignments per exact book content. */
object DialogueCorrectionStore {
    private const val PREFS = "fb2audioprep_dialogue_corrections"
    private const val PREFIX = "book_"

    private data class Correction(
        val index: Int,
        val fragmentHash: String,
        val speaker: String?,
        val voice: String?
    )

    fun apply(context: Context, bookText: String, findings: List<DialogueFinding>): List<DialogueFinding> {
        val corrections = read(context, bookText)
        if (corrections.isEmpty()) return findings
        return findings.mapIndexed { index, finding ->
            val correction = corrections[index]
            if (correction == null || correction.fragmentHash != sha256(finding.fragment)) {
                finding
            } else {
                finding.copy(
                    speaker = correction.speaker,
                    voice = correction.voice,
                    confidence = if (correction.speaker == null) 0f else 1f,
                    reason = if (correction.speaker == null)
                        "Пользователь сохранил: не назначать персонажа"
                    else "Говорящий восстановлен из ручной проверки"
                )
            }
        }
    }

    fun save(context: Context, bookText: String, index: Int, finding: DialogueFinding) {
        require(index >= 0) { "Некорректный номер фрагмента" }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = key(bookText)
        val root = try { JSONObject(prefs.getString(key, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val items = root.optJSONObject("items") ?: JSONObject()
        val item = JSONObject()
            .put("fragmentHash", sha256(finding.fragment))
            .put("speaker", finding.speaker ?: JSONObject.NULL)
            .put("voice", finding.voice ?: JSONObject.NULL)
        items.put(index.toString(), item)
        root.put("version", 1)
        root.put("items", items)
        prefs.edit().putString(key, root.toString()).apply()
    }

    fun clear(context: Context, bookText: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(key(bookText)).apply()
    }

    fun count(context: Context, bookText: String): Int = read(context, bookText).size

    private fun read(context: Context, bookText: String): Map<Int, Correction> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key(bookText), null)
            ?: return emptyMap()
        return try {
            val items = JSONObject(raw).optJSONObject("items") ?: return emptyMap()
            val result = LinkedHashMap<Int, Correction>()
            val keys = items.keys()
            while (keys.hasNext()) {
                val indexText = keys.next()
                val index = indexText.toIntOrNull() ?: continue
                val item = items.optJSONObject(indexText) ?: continue
                val speaker = if (item.isNull("speaker")) null else item.optString("speaker").takeIf { it.isNotBlank() }
                val voice = if (item.isNull("voice")) null else item.optString("voice").takeIf { it.isNotBlank() }
                result[index] = Correction(index, item.optString("fragmentHash"), speaker, voice)
            }
            result
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun key(bookText: String): String = PREFIX + sha256(bookText)

    private fun sha256(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
