package ru.fbaudioprep

import java.text.Normalizer
import java.util.Locale

data class AccentResult(
    val text: String,
    val changedWords: Int,
    val unknownWords: List<String>,
    val alreadyAccentedWords: Int
)

/** Offline dictionary-first accentuation. Unknown words are deliberately not guessed. */
class AccentEngine(
    builtInDictionary: Map<String, String> = emptyMap(),
    userDictionary: Map<String, String> = emptyMap()
) {
    private val dictionary = LinkedHashMap<String, String>().apply {
        putAll(builtInDictionary.mapKeys { normalizeKey(it.key) })
        putAll(userDictionary.mapKeys { normalizeKey(it.key) })
    }

    fun process(input: String): AccentResult {
        val unknown = linkedSetOf<String>()
        var changed = 0
        var already = 0
        val wordRegex = Regex("""[\p{L}\p{M}]+(?:[-‑][\p{L}\p{M}]+)*""")
        val output = wordRegex.replace(input) { match ->
            val original = match.value
            if (ACUTE in original) {
                already++
                return@replace original
            }
            val accented = dictionary[normalizeKey(original)]
            if (accented == null) {
                if (original.any { it in RUSSIAN_LETTERS }) unknown.add(original)
                original
            } else {
                changed++
                preserveCase(original, accented)
            }
        }
        return AccentResult(output, changed, unknown.toList(), already)
    }

    fun withEntry(word: String, accentedForm: String): AccentEngine {
        require(word.any { it.isLetter() }) { "Пустое слово" }
        require(accentedForm.any { it == ACUTE }) { "В форме должно быть ударение U+0301" }
        require(normalizeKey(word) == normalizeKey(accentedForm)) {
            "Форма должна совпадать со словом без знаков ударения"
        }
        val updated = LinkedHashMap(dictionary)
        updated[normalizeKey(word)] = accentedForm
        return AccentEngine(updated)
    }

    private fun normalizeKey(value: String): String =
        Normalizer.normalize(value.replace(ACUTE.toString(), ""), Normalizer.Form.NFC)
            .lowercase(Locale.ROOT)

    private fun preserveCase(source: String, target: String): String {
        val letters = source.filter { it.isLetter() }
        return when {
            letters.isNotEmpty() && letters == letters.uppercase(Locale.ROOT) -> target.uppercase(Locale.ROOT)
            source.firstOrNull()?.isUpperCase() == true ->
                target.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
            else -> target
        }
    }

    companion object {
        const val ACUTE: Char = '\u0301'
        private const val RUSSIAN_LETTERS =
            "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя"
    }
}
