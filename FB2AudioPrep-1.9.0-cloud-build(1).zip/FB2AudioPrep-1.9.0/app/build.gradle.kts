plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "ru.fbaudioprep"; compileSdk = 35
    defaultConfig { applicationId = "ru.fbaudioprep"; minSdk = 26; targetSdk = 35; versionCode = 20; versionName = "1.9.0" }
}
